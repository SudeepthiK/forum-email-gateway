
package org.mule.modules.config;

import org.mule.api.MuleContext;
import org.mule.api.config.MuleProperties;
import org.mule.api.context.MuleContextAware;
import org.mule.api.store.ObjectStoreManager;

public class ObjectStoreModuleInjectAdapter
    extends ObjectStoreModuleLifecycleAdapter
    implements MuleContextAware
{


    @Override
    public void setMuleContext(MuleContext context) {
        super.setObjectStoreManager(((ObjectStoreManager) context.getRegistry().get(MuleProperties.OBJECT_STORE_MANAGER)));
    }

}
