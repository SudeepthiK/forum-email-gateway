
package org.mule.module.ldap.config;

import java.util.Map;
import org.apache.commons.pool.KeyedPoolableObjectFactory;
import org.apache.commons.pool.impl.GenericKeyedObjectPool;
import org.mule.api.Capabilities;
import org.mule.api.Capability;
import org.mule.api.ConnectionManager;
import org.mule.api.MuleContext;
import org.mule.api.construct.FlowConstruct;
import org.mule.api.lifecycle.Disposable;
import org.mule.api.lifecycle.Initialisable;
import org.mule.api.lifecycle.Startable;
import org.mule.api.lifecycle.Stoppable;
import org.mule.config.PoolingProfile;
import org.mule.module.ldap.LDAPConnector;
import org.mule.module.ldap.Referral;
import org.mule.module.ldap.Type;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * A {@code LDAPConnectorConnectionManager} is a wrapper around {@link LDAPConnector } that adds connection management capabilities to the pojo.
 * 
 */
public class LDAPConnectorConnectionManager
    implements Capabilities, ConnectionManager<LDAPConnectorConnectionManager.ConnectionParameters, LDAPConnectorLifecycleAdapter> , Initialisable
{

    private String authDn;
    private String authPassword;
    private String url;
    private Type type;
    private String authentication;
    private int initialPoolSize;
    private int maxPoolSize;
    private long poolTimeout;
    private Referral referral;
    private Map<String, String> extendedConfiguration;
    private static Logger logger = LoggerFactory.getLogger(LDAPConnectorConnectionManager.class);
    /**
     * Mule Context
     * 
     */
    private MuleContext muleContext;
    /**
     * Flow construct
     * 
     */
    private FlowConstruct flowConstruct;
    /**
     * Connector Pool
     * 
     */
    private GenericKeyedObjectPool connectionPool;
    protected PoolingProfile connectionPoolingProfile;

    /**
     * Sets url
     * 
     * @param value Value to set
     */
    public void setUrl(String value) {
        this.url = value;
    }

    /**
     * Retrieves url
     * 
     */
    public String getUrl() {
        return this.url;
    }

    /**
     * Sets type
     * 
     * @param value Value to set
     */
    public void setType(Type value) {
        this.type = value;
    }

    /**
     * Retrieves type
     * 
     */
    public Type getType() {
        return this.type;
    }

    /**
     * Sets authentication
     * 
     * @param value Value to set
     */
    public void setAuthentication(String value) {
        this.authentication = value;
    }

    /**
     * Retrieves authentication
     * 
     */
    public String getAuthentication() {
        return this.authentication;
    }

    /**
     * Sets initialPoolSize
     * 
     * @param value Value to set
     */
    public void setInitialPoolSize(int value) {
        this.initialPoolSize = value;
    }

    /**
     * Retrieves initialPoolSize
     * 
     */
    public int getInitialPoolSize() {
        return this.initialPoolSize;
    }

    /**
     * Sets maxPoolSize
     * 
     * @param value Value to set
     */
    public void setMaxPoolSize(int value) {
        this.maxPoolSize = value;
    }

    /**
     * Retrieves maxPoolSize
     * 
     */
    public int getMaxPoolSize() {
        return this.maxPoolSize;
    }

    /**
     * Sets poolTimeout
     * 
     * @param value Value to set
     */
    public void setPoolTimeout(long value) {
        this.poolTimeout = value;
    }

    /**
     * Retrieves poolTimeout
     * 
     */
    public long getPoolTimeout() {
        return this.poolTimeout;
    }

    /**
     * Sets referral
     * 
     * @param value Value to set
     */
    public void setReferral(Referral value) {
        this.referral = value;
    }

    /**
     * Retrieves referral
     * 
     */
    public Referral getReferral() {
        return this.referral;
    }

    /**
     * Sets extendedConfiguration
     * 
     * @param value Value to set
     */
    public void setExtendedConfiguration(Map<String, String> value) {
        this.extendedConfiguration = value;
    }

    /**
     * Retrieves extendedConfiguration
     * 
     */
    public Map<String, String> getExtendedConfiguration() {
        return this.extendedConfiguration;
    }

    /**
     * Sets connectionPoolingProfile
     * 
     * @param value Value to set
     */
    public void setConnectionPoolingProfile(PoolingProfile value) {
        this.connectionPoolingProfile = value;
    }

    /**
     * Retrieves connectionPoolingProfile
     * 
     */
    public PoolingProfile getConnectionPoolingProfile() {
        return this.connectionPoolingProfile;
    }

    /**
     * Sets authPassword
     * 
     * @param value Value to set
     */
    public void setAuthPassword(String value) {
        this.authPassword = value;
    }

    /**
     * Retrieves authPassword
     * 
     */
    public String getAuthPassword() {
        return this.authPassword;
    }

    /**
     * Sets authDn
     * 
     * @param value Value to set
     */
    public void setAuthDn(String value) {
        this.authDn = value;
    }

    /**
     * Retrieves authDn
     * 
     */
    public String getAuthDn() {
        return this.authDn;
    }

    /**
     * Sets flow construct
     * 
     * @param flowConstruct Flow construct to set
     */
    public void setFlowConstruct(FlowConstruct flowConstruct) {
        this.flowConstruct = flowConstruct;
    }

    /**
     * Set the Mule context
     * 
     * @param context Mule context to set
     */
    public void setMuleContext(MuleContext context) {
        this.muleContext = context;
    }

    public void initialise() {
        GenericKeyedObjectPool.Config config = new GenericKeyedObjectPool.Config();
        if (connectionPoolingProfile!= null) {
            config.maxIdle = connectionPoolingProfile.getMaxIdle();
            config.maxActive = connectionPoolingProfile.getMaxActive();
            config.maxWait = connectionPoolingProfile.getMaxWait();
            config.whenExhaustedAction = ((byte) connectionPoolingProfile.getExhaustedAction());
        }
        connectionPool = new GenericKeyedObjectPool(new LDAPConnectorConnectionManager.ConnectionFactory(this), config);
    }

    public LDAPConnectorLifecycleAdapter acquireConnection(LDAPConnectorConnectionManager.ConnectionParameters key)
        throws Exception
    {
        return ((LDAPConnectorLifecycleAdapter) connectionPool.borrowObject(key));
    }

    public void releaseConnection(LDAPConnectorConnectionManager.ConnectionParameters key, LDAPConnectorLifecycleAdapter connection)
        throws Exception
    {
        connectionPool.returnObject(key, connection);
    }

    public void destroyConnection(LDAPConnectorConnectionManager.ConnectionParameters key, LDAPConnectorLifecycleAdapter connection)
        throws Exception
    {
        connectionPool.invalidateObject(key, connection);
    }

    /**
     * Returns true if this module implements such capability
     * 
     */
    public boolean isCapableOf(Capability capability) {
        if (capability == Capability.LIFECYCLE_CAPABLE) {
            return true;
        }
        if (capability == Capability.CONNECTION_MANAGEMENT_CAPABLE) {
            return true;
        }
        return false;
    }

    private static class ConnectionFactory
        implements KeyedPoolableObjectFactory
    {

        private LDAPConnectorConnectionManager connectionManager;

        public ConnectionFactory(LDAPConnectorConnectionManager connectionManager) {
            this.connectionManager = connectionManager;
        }

        public Object makeObject(Object key)
            throws Exception
        {
            if (!(key instanceof LDAPConnectorConnectionManager.ConnectionParameters)) {
                throw new RuntimeException("Invalid key type");
            }
            LDAPConnectorLifecycleAdapter connector = new LDAPConnectorLifecycleAdapter();
            connector.setUrl(connectionManager.getUrl());
            connector.setType(connectionManager.getType());
            connector.setAuthentication(connectionManager.getAuthentication());
            connector.setInitialPoolSize(connectionManager.getInitialPoolSize());
            connector.setMaxPoolSize(connectionManager.getMaxPoolSize());
            connector.setPoolTimeout(connectionManager.getPoolTimeout());
            connector.setReferral(connectionManager.getReferral());
            connector.setExtendedConfiguration(connectionManager.getExtendedConfiguration());
            if (connector instanceof Initialisable) {
                connector.initialise();
            }
            if (connector instanceof Startable) {
                connector.start();
            }
            return connector;
        }

        public void destroyObject(Object key, Object obj)
            throws Exception
        {
            if (!(key instanceof LDAPConnectorConnectionManager.ConnectionParameters)) {
                throw new RuntimeException("Invalid key type");
            }
            if (!(obj instanceof LDAPConnectorLifecycleAdapter)) {
                throw new RuntimeException("Invalid connector type");
            }
            try {
                ((LDAPConnectorLifecycleAdapter) obj).disconnect();
            } catch (Exception e) {
                throw e;
            } finally {
                if (((LDAPConnectorLifecycleAdapter) obj) instanceof Stoppable) {
                    ((LDAPConnectorLifecycleAdapter) obj).stop();
                }
                if (((LDAPConnectorLifecycleAdapter) obj) instanceof Disposable) {
                    ((LDAPConnectorLifecycleAdapter) obj).dispose();
                }
            }
        }

        public boolean validateObject(Object key, Object obj) {
            if (!(obj instanceof LDAPConnectorLifecycleAdapter)) {
                throw new RuntimeException("Invalid connector type");
            }
            try {
                return ((LDAPConnectorLifecycleAdapter) obj).isConnected();
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
                return false;
            }
        }

        public void activateObject(Object key, Object obj)
            throws Exception
        {
            if (!(key instanceof LDAPConnectorConnectionManager.ConnectionParameters)) {
                throw new RuntimeException("Invalid key type");
            }
            if (!(obj instanceof LDAPConnectorLifecycleAdapter)) {
                throw new RuntimeException("Invalid connector type");
            }
            try {
                if (!((LDAPConnectorLifecycleAdapter) obj).isConnected()) {
                    ((LDAPConnectorLifecycleAdapter) obj).connect(((LDAPConnectorConnectionManager.ConnectionParameters) key).getAuthPassword(), ((LDAPConnectorConnectionManager.ConnectionParameters) key).getAuthDn());
                }
            } catch (Exception e) {
                throw e;
            }
        }

        public void passivateObject(Object key, Object obj)
            throws Exception
        {
        }

    }

    public static class ConnectionParameters {

        private String authDn;
        private String authPassword;

        public ConnectionParameters(String authDn, String authPassword) {
            this.authDn = authDn;
            this.authPassword = authPassword;
        }

        /**
         * Sets authPassword
         * 
         * @param value Value to set
         */
        public void setAuthPassword(String value) {
            this.authPassword = value;
        }

        /**
         * Retrieves authPassword
         * 
         */
        public String getAuthPassword() {
            return this.authPassword;
        }

        /**
         * Sets authDn
         * 
         * @param value Value to set
         */
        public void setAuthDn(String value) {
            this.authDn = value;
        }

        /**
         * Retrieves authDn
         * 
         */
        public String getAuthDn() {
            return this.authDn;
        }

        public int hashCode() {
            int hash = 1;
            hash = ((hash* 31)+ this.authDn.hashCode());
            return hash;
        }

        public boolean equals(Object obj) {
            return ((obj instanceof LDAPConnectorConnectionManager.ConnectionParameters)&&(this.authDn == ((LDAPConnectorConnectionManager.ConnectionParameters) obj).authDn));
        }

    }

}
