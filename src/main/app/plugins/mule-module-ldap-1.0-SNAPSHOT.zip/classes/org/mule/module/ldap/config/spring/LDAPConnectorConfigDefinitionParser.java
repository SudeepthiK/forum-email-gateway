
package org.mule.module.ldap.config.spring;

import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.mule.api.lifecycle.Disposable;
import org.mule.api.lifecycle.Initialisable;
import org.mule.config.PoolingProfile;
import org.mule.config.spring.MuleHierarchicalBeanDefinitionParserDelegate;
import org.mule.config.spring.parsers.generic.AutoIdUtils;
import org.mule.module.ldap.config.LDAPConnectorConnectionManager;
import org.mule.util.TemplateParser;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.RuntimeBeanReference;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.ManagedMap;
import org.springframework.beans.factory.xml.BeanDefinitionParser;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.util.xml.DomUtils;
import org.w3c.dom.Element;

public class LDAPConnectorConfigDefinitionParser
    implements BeanDefinitionParser
{

    /**
     * Mule Pattern Info
     * 
     */
    private TemplateParser.PatternInfo patternInfo;

    public LDAPConnectorConfigDefinitionParser() {
        patternInfo = TemplateParser.createMuleStyleParser().getStyle();
    }

    public BeanDefinition parse(Element element, ParserContext parserContent) {
        String name = element.getAttribute("name");
        if ((name == null)||StringUtils.isBlank(name)) {
            element.setAttribute("name", AutoIdUtils.getUniqueName(element, "mule-bean"));
        }
        BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(LDAPConnectorConnectionManager.class.getName());
        if (Initialisable.class.isAssignableFrom(LDAPConnectorConnectionManager.class)) {
            builder.setInitMethodName(Initialisable.PHASE_NAME);
        }
        if (Disposable.class.isAssignableFrom(LDAPConnectorConnectionManager.class)) {
            builder.setDestroyMethodName(Disposable.PHASE_NAME);
        }
        if ((element.getAttribute("url")!= null)&&(!StringUtils.isBlank(element.getAttribute("url")))) {
            builder.addPropertyValue("url", element.getAttribute("url"));
        }
        if (element.hasAttribute("type")) {
            builder.addPropertyValue("type", element.getAttribute("type"));
        }
        if ((element.getAttribute("authentication")!= null)&&(!StringUtils.isBlank(element.getAttribute("authentication")))) {
            builder.addPropertyValue("authentication", element.getAttribute("authentication"));
        }
        if ((element.getAttribute("initialPoolSize")!= null)&&(!StringUtils.isBlank(element.getAttribute("initialPoolSize")))) {
            builder.addPropertyValue("initialPoolSize", element.getAttribute("initialPoolSize"));
        }
        if ((element.getAttribute("maxPoolSize")!= null)&&(!StringUtils.isBlank(element.getAttribute("maxPoolSize")))) {
            builder.addPropertyValue("maxPoolSize", element.getAttribute("maxPoolSize"));
        }
        if ((element.getAttribute("poolTimeout")!= null)&&(!StringUtils.isBlank(element.getAttribute("poolTimeout")))) {
            builder.addPropertyValue("poolTimeout", element.getAttribute("poolTimeout"));
        }
        if (element.hasAttribute("referral")) {
            builder.addPropertyValue("referral", element.getAttribute("referral"));
        }
        Element extendedConfigurationListElement = null;
        extendedConfigurationListElement = DomUtils.getChildElementByTagName(element, "extended-configuration");
        List<Element> extendedConfigurationListChilds = null;
        if (extendedConfigurationListElement!= null) {
            String extendedConfigurationRef = extendedConfigurationListElement.getAttribute("ref");
            if ((extendedConfigurationRef!= null)&&(!StringUtils.isBlank(extendedConfigurationRef))) {
                if ((!extendedConfigurationRef.startsWith(patternInfo.getPrefix()))&&(!extendedConfigurationRef.endsWith(patternInfo.getSuffix()))) {
                    builder.addPropertyValue("extendedConfiguration", new RuntimeBeanReference(extendedConfigurationRef));
                } else {
                    builder.addPropertyValue("extendedConfiguration", extendedConfigurationRef);
                }
            } else {
                ManagedMap extendedConfiguration = new ManagedMap();
                extendedConfigurationListChilds = DomUtils.getChildElementsByTagName(extendedConfigurationListElement, "extended-configuration");
                if (extendedConfigurationListChilds!= null) {
                    if (extendedConfigurationListChilds.size() == 0) {
                        extendedConfigurationListChilds = DomUtils.getChildElements(extendedConfigurationListElement);
                    }
                    for (Element extendedConfigurationChild: extendedConfigurationListChilds) {
                        String extendedConfigurationValueRef = extendedConfigurationChild.getAttribute("value-ref");
                        String extendedConfigurationKeyRef = extendedConfigurationChild.getAttribute("key-ref");
                        Object valueObject = null;
                        Object keyObject = null;
                        if ((extendedConfigurationValueRef!= null)&&(!StringUtils.isBlank(extendedConfigurationValueRef))) {
                            valueObject = new RuntimeBeanReference(extendedConfigurationValueRef);
                        } else {
                            valueObject = extendedConfigurationChild.getTextContent();
                        }
                        if ((extendedConfigurationKeyRef!= null)&&(!StringUtils.isBlank(extendedConfigurationKeyRef))) {
                            keyObject = new RuntimeBeanReference(extendedConfigurationKeyRef);
                        } else {
                            keyObject = extendedConfigurationChild.getAttribute("key");
                        }
                        if ((keyObject == null)||((keyObject instanceof String)&&StringUtils.isBlank(((String) keyObject)))) {
                            keyObject = extendedConfigurationChild.getTagName();
                        }
                        extendedConfiguration.put(keyObject, valueObject);
                    }
                }
                builder.addPropertyValue("extendedConfiguration", extendedConfiguration);
            }
        }
        if ((element.getAttribute("authDn")!= null)&&(!StringUtils.isBlank(element.getAttribute("authDn")))) {
            builder.addPropertyValue("authDn", element.getAttribute("authDn"));
        }
        if ((element.getAttribute("authPassword")!= null)&&(!StringUtils.isBlank(element.getAttribute("authPassword")))) {
            builder.addPropertyValue("authPassword", element.getAttribute("authPassword"));
        }
        BeanDefinitionBuilder connectionPoolingProfileBuilder = BeanDefinitionBuilder.rootBeanDefinition(PoolingProfile.class.getName());
        Element connectionPoolingProfileElement = DomUtils.getChildElementByTagName(element, "connection-pooling-profile");
        if (connectionPoolingProfileElement!= null) {
            if ((connectionPoolingProfileElement.getAttribute("maxActive")!= null)&&(!StringUtils.isBlank(connectionPoolingProfileElement.getAttribute("maxActive")))) {
                connectionPoolingProfileBuilder.addPropertyValue("maxActive", connectionPoolingProfileElement.getAttribute("maxActive"));
            }
            if ((connectionPoolingProfileElement.getAttribute("maxIdle")!= null)&&(!StringUtils.isBlank(connectionPoolingProfileElement.getAttribute("maxIdle")))) {
                connectionPoolingProfileBuilder.addPropertyValue("maxIdle", connectionPoolingProfileElement.getAttribute("maxIdle"));
            }
            if ((connectionPoolingProfileElement.getAttribute("maxWait")!= null)&&(!StringUtils.isBlank(connectionPoolingProfileElement.getAttribute("maxWait")))) {
                connectionPoolingProfileBuilder.addPropertyValue("maxWait", connectionPoolingProfileElement.getAttribute("maxWait"));
            }
            if ((connectionPoolingProfileElement.getAttribute("exhaustedAction")!= null)&&(!StringUtils.isBlank(connectionPoolingProfileElement.getAttribute("exhaustedAction")))) {
                connectionPoolingProfileBuilder.addPropertyValue("exhaustedAction", PoolingProfile.POOL_EXHAUSTED_ACTIONS.get(connectionPoolingProfileElement.getAttribute("exhaustedAction")));
            }
            if ((connectionPoolingProfileElement.getAttribute("exhaustedAction")!= null)&&(!StringUtils.isBlank(connectionPoolingProfileElement.getAttribute("exhaustedAction")))) {
                connectionPoolingProfileBuilder.addPropertyValue("initialisationPolicy", PoolingProfile.POOL_INITIALISATION_POLICIES.get(connectionPoolingProfileElement.getAttribute("initialisationPolicy")));
            }
            builder.addPropertyValue("connectionPoolingProfile", connectionPoolingProfileBuilder.getBeanDefinition());
        }
        BeanDefinition definition = builder.getBeanDefinition();
        definition.setAttribute(MuleHierarchicalBeanDefinitionParserDelegate.MULE_NO_RECURSE, Boolean.TRUE);
        return definition;
    }

}
