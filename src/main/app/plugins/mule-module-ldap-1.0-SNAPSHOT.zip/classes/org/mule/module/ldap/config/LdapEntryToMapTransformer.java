
package org.mule.module.ldap.config;

import java.util.Map;
import org.mule.api.transformer.DiscoverableTransformer;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.module.ldap.LDAPConnector;
import org.mule.transformer.AbstractTransformer;
import org.mule.transformer.types.DataTypeFactory;

public class LdapEntryToMapTransformer
    extends AbstractTransformer
    implements DiscoverableTransformer
{

    private int weighting = (DiscoverableTransformer.DEFAULT_PRIORITY_WEIGHTING + 5);

    public LdapEntryToMapTransformer() {
        registerSourceType(DataTypeFactory.create(org.mule.module.ldap.ldap.api.LDAPEntry.class));
        registerSourceType(DataTypeFactory.create(org.mule.module.ldap.ldap.api.LDAPEntry.class));
        setReturnClass(Map.class);
        setName("org.mule.module.ldap.LdapEntryToMapTransformer");
    }

    protected Object doTransform(Object src, String encoding)
        throws TransformerException
    {
        Map<String, Object> result = null;
        try {
            result = LDAPConnector.ldapEntryToMap(((org.mule.module.ldap.ldap.api.LDAPEntry) src));
        } catch (Exception exception) {
            throw new TransformerException(CoreMessages.transformFailed(src.getClass().getName(), "java.util.Map<java.lang.String,java.lang.Object>"), this, exception);
        }
        return result;
    }

    public int getPriorityWeighting() {
        return weighting;
    }

    public void setPriorityWeighting(int weighting) {
        this.weighting = weighting;
    }

}
