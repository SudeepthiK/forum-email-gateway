
package org.mule.module.ldap.config.spring;

import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.mule.config.spring.MuleHierarchicalBeanDefinitionParserDelegate;
import org.mule.config.spring.util.SpringXMLUtils;
import org.mule.module.ldap.config.SearchOneMessageProcessor;
import org.mule.util.TemplateParser;
import org.springframework.beans.MutablePropertyValues;
import org.springframework.beans.PropertyValue;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.RuntimeBeanReference;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.ManagedList;
import org.springframework.beans.factory.xml.BeanDefinitionParser;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.util.xml.DomUtils;
import org.w3c.dom.Element;

public class SearchOneDefinitionParser
    implements BeanDefinitionParser
{

    /**
     * Mule Pattern Info
     * 
     */
    private TemplateParser.PatternInfo patternInfo;

    public SearchOneDefinitionParser() {
        patternInfo = TemplateParser.createMuleStyleParser().getStyle();
    }

    public BeanDefinition parse(Element element, ParserContext parserContent) {
        BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(SearchOneMessageProcessor.class.getName());
        String configRef = element.getAttribute("config-ref");
        if ((configRef!= null)&&(!StringUtils.isBlank(configRef))) {
            builder.addPropertyValue("moduleObject", configRef);
        }
        if ((element.getAttribute("baseDn")!= null)&&(!StringUtils.isBlank(element.getAttribute("baseDn")))) {
            builder.addPropertyValue("baseDn", element.getAttribute("baseDn"));
        }
        if ((element.getAttribute("filter")!= null)&&(!StringUtils.isBlank(element.getAttribute("filter")))) {
            builder.addPropertyValue("filter", element.getAttribute("filter"));
        }
        Element attributesListElement = null;
        attributesListElement = DomUtils.getChildElementByTagName(element, "attributes");
        List<Element> attributesListChilds = null;
        if (attributesListElement!= null) {
            String attributesRef = attributesListElement.getAttribute("ref");
            if ((attributesRef!= null)&&(!StringUtils.isBlank(attributesRef))) {
                if ((!attributesRef.startsWith(patternInfo.getPrefix()))&&(!attributesRef.endsWith(patternInfo.getSuffix()))) {
                    builder.addPropertyValue("attributes", new RuntimeBeanReference(attributesRef));
                } else {
                    builder.addPropertyValue("attributes", attributesRef);
                }
            } else {
                ManagedList attributes = new ManagedList();
                attributesListChilds = DomUtils.getChildElementsByTagName(attributesListElement, "attribute");
                if (attributesListChilds!= null) {
                    for (Element attributesChild: attributesListChilds) {
                        String valueRef = attributesChild.getAttribute("value-ref");
                        if ((valueRef!= null)&&(!StringUtils.isBlank(valueRef))) {
                            attributes.add(new RuntimeBeanReference(valueRef));
                        } else {
                            attributes.add(attributesChild.getTextContent());
                        }
                    }
                }
                builder.addPropertyValue("attributes", attributes);
            }
        }
        if (element.hasAttribute("scope")) {
            builder.addPropertyValue("scope", element.getAttribute("scope"));
        }
        if ((element.getAttribute("timeout")!= null)&&(!StringUtils.isBlank(element.getAttribute("timeout")))) {
            builder.addPropertyValue("timeout", element.getAttribute("timeout"));
        }
        if ((element.getAttribute("maxResults")!= null)&&(!StringUtils.isBlank(element.getAttribute("maxResults")))) {
            builder.addPropertyValue("maxResults", element.getAttribute("maxResults"));
        }
        if ((element.getAttribute("returnObject")!= null)&&(!StringUtils.isBlank(element.getAttribute("returnObject")))) {
            builder.addPropertyValue("returnObject", element.getAttribute("returnObject"));
        }
        if ((element.getAttribute("retryMax")!= null)&&(!StringUtils.isBlank(element.getAttribute("retryMax")))) {
            builder.addPropertyValue("retryMax", element.getAttribute("retryMax"));
        }
        if ((element.getAttribute("authDn")!= null)&&(!StringUtils.isBlank(element.getAttribute("authDn")))) {
            builder.addPropertyValue("authDn", element.getAttribute("authDn"));
        }
        if ((element.getAttribute("authPassword")!= null)&&(!StringUtils.isBlank(element.getAttribute("authPassword")))) {
            builder.addPropertyValue("authPassword", element.getAttribute("authPassword"));
        }
        BeanDefinition definition = builder.getBeanDefinition();
        definition.setAttribute(MuleHierarchicalBeanDefinitionParserDelegate.MULE_NO_RECURSE, Boolean.TRUE);
        MutablePropertyValues propertyValues = parserContent.getContainingBeanDefinition().getPropertyValues();
        if (parserContent.getContainingBeanDefinition().getBeanClassName().equals("org.mule.config.spring.factories.PollingMessageSourceFactoryBean")) {
            propertyValues.addPropertyValue("messageProcessor", definition);
        } else {
            PropertyValue messageProcessors = propertyValues.getPropertyValue("messageProcessors");
            if ((messageProcessors == null)||(messageProcessors.getValue() == null)) {
                propertyValues.addPropertyValue("messageProcessors", new ManagedList());
            }
            List listMessageProcessors = ((List) propertyValues.getPropertyValue("messageProcessors").getValue());
            listMessageProcessors.add(definition);
        }
        return definition;
    }

    protected String getAttributeValue(Element element, String attributeName) {
        if (!StringUtils.isEmpty(element.getAttribute(attributeName))) {
            return element.getAttribute(attributeName);
        }
        return null;
    }

    private String generateChildBeanName(Element element) {
        String id = SpringXMLUtils.getNameOrId(element);
        if (StringUtils.isBlank(id)) {
            String parentId = SpringXMLUtils.getNameOrId(((Element) element.getParentNode()));
            return ((("."+ parentId)+":")+ element.getLocalName());
        } else {
            return id;
        }
    }

}
