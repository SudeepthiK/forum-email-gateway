
package org.mule.module.config;

import org.mule.api.Capabilities;
import org.mule.api.Capability;


/**
 * A <code>BridgeTableModuleCapabilitiesAdapter</code> is a wrapper around {@link org.mule.module.BridgeTableModule } that implements {@link org.mule.api.Capabilities} interface.
 * 
 */
public class BridgeTableModuleCapabilitiesAdapter
    extends org.mule.module.BridgeTableModule
    implements Capabilities
{


    /**
     * Returns true if this module implements such capability
     * 
     */
    public boolean isCapableOf(Capability capability) {
        if (capability == Capability.LIFECYCLE_CAPABLE) {
            return true;
        }
        return false;
    }

}
