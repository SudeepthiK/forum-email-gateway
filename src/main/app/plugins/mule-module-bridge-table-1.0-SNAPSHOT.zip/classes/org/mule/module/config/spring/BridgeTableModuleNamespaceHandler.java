
package org.mule.module.config.spring;

import org.springframework.beans.factory.xml.NamespaceHandlerSupport;


/**
 * Registers bean definitions parsers for handling elements in <code>http://www.mulesoft.org/schema/mule/bridgetable</code>.
 * 
 */
public class BridgeTableModuleNamespaceHandler
    extends NamespaceHandlerSupport
{


    /**
     * Invoked by the {@link DefaultBeanDefinitionDocumentReader} after construction but before any custom elements are parsed. 
     * @see NamespaceHandlerSupport#registerBeanDefinitionParser(String, BeanDefinitionParser)
     * 
     */
    public void init() {
        registerBeanDefinitionParser("config", new BridgeTableModuleConfigDefinitionParser());
        registerBeanDefinitionParser("insert", new InsertDefinitionParser());
        registerBeanDefinitionParser("upsert-by-key1", new UpsertByKey1DefinitionParser());
        registerBeanDefinitionParser("upsert-by-key2", new UpsertByKey2DefinitionParser());
        registerBeanDefinitionParser("update-by-key1", new UpdateByKey1DefinitionParser());
        registerBeanDefinitionParser("update-by-key2", new UpdateByKey2DefinitionParser());
        registerBeanDefinitionParser("remove-by-key1", new RemoveByKey1DefinitionParser());
        registerBeanDefinitionParser("remove-by-key2", new RemoveByKey2DefinitionParser());
        registerBeanDefinitionParser("retrieve-by-key1", new RetrieveByKey1DefinitionParser());
        registerBeanDefinitionParser("retrieve-by-key2", new RetrieveByKey2DefinitionParser());
        registerBeanDefinitionParser("contains-key1", new ContainsKey1DefinitionParser());
        registerBeanDefinitionParser("contains-key2", new ContainsKey2DefinitionParser());
        registerBeanDefinitionParser("keys1", new Keys1DefinitionParser());
        registerBeanDefinitionParser("keys2", new Keys2DefinitionParser());
    }

}
