
package org.mule.module.config.spring;

import org.apache.commons.lang.StringUtils;
import org.mule.api.lifecycle.Disposable;
import org.mule.api.lifecycle.Initialisable;
import org.mule.config.spring.MuleHierarchicalBeanDefinitionParserDelegate;
import org.mule.config.spring.parsers.generic.AutoIdUtils;
import org.mule.module.config.BridgeTableModuleLifecycleAdapter;
import org.mule.util.TemplateParser;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.RuntimeBeanReference;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.BeanDefinitionParser;
import org.springframework.beans.factory.xml.ParserContext;
import org.w3c.dom.Element;

public class BridgeTableModuleConfigDefinitionParser
    implements BeanDefinitionParser
{

    /**
     * Mule Pattern Info
     * 
     */
    private TemplateParser.PatternInfo patternInfo;

    public BridgeTableModuleConfigDefinitionParser() {
        patternInfo = TemplateParser.createMuleStyleParser().getStyle();
    }

    public BeanDefinition parse(Element element, ParserContext parserContent) {
        String name = element.getAttribute("name");
        if ((name == null)||StringUtils.isBlank(name)) {
            element.setAttribute("name", AutoIdUtils.getUniqueName(element, "mule-bean"));
        }
        BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(BridgeTableModuleLifecycleAdapter.class.getName());
        if (Initialisable.class.isAssignableFrom(BridgeTableModuleLifecycleAdapter.class)) {
            builder.setInitMethodName(Initialisable.PHASE_NAME);
        }
        if (Disposable.class.isAssignableFrom(BridgeTableModuleLifecycleAdapter.class)) {
            builder.setDestroyMethodName(Disposable.PHASE_NAME);
        }
        if ((element.getAttribute("tableName")!= null)&&(!StringUtils.isBlank(element.getAttribute("tableName")))) {
            builder.addPropertyValue("tableName", element.getAttribute("tableName"));
        }
        if (element.hasAttribute("type")) {
            builder.addPropertyValue("type", element.getAttribute("type"));
        }
        if ((element.getAttribute("dataSource-ref")!= null)&&(!StringUtils.isBlank(element.getAttribute("dataSource-ref")))) {
            builder.addPropertyValue("dataSource", new RuntimeBeanReference(element.getAttribute("dataSource-ref")));
        }
        if ((element.getAttribute("autoCreateTable")!= null)&&(!StringUtils.isBlank(element.getAttribute("autoCreateTable")))) {
            builder.addPropertyValue("autoCreateTable", element.getAttribute("autoCreateTable"));
        }
        if (element.hasAttribute("key1Type")) {
            builder.addPropertyValue("key1Type", element.getAttribute("key1Type"));
        }
        if ((element.getAttribute("key1Name")!= null)&&(!StringUtils.isBlank(element.getAttribute("key1Name")))) {
            builder.addPropertyValue("key1Name", element.getAttribute("key1Name"));
        }
        if ((element.getAttribute("key2Name")!= null)&&(!StringUtils.isBlank(element.getAttribute("key2Name")))) {
            builder.addPropertyValue("key2Name", element.getAttribute("key2Name"));
        }
        if (element.hasAttribute("key2Type")) {
            builder.addPropertyValue("key2Type", element.getAttribute("key2Type"));
        }
        if ((element.getAttribute("allowEmptyKeys")!= null)&&(!StringUtils.isBlank(element.getAttribute("allowEmptyKeys")))) {
            builder.addPropertyValue("allowEmptyKeys", element.getAttribute("allowEmptyKeys"));
        }
        if ((element.getAttribute("returnValueAsString")!= null)&&(!StringUtils.isBlank(element.getAttribute("returnValueAsString")))) {
            builder.addPropertyValue("returnValueAsString", element.getAttribute("returnValueAsString"));
        }
        BeanDefinition definition = builder.getBeanDefinition();
        definition.setAttribute(MuleHierarchicalBeanDefinitionParserDelegate.MULE_NO_RECURSE, Boolean.TRUE);
        return definition;
    }

}
