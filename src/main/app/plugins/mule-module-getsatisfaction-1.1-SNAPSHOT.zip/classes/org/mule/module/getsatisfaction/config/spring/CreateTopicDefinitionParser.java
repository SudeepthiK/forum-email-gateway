
package org.mule.module.getsatisfaction.config.spring;

import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.mule.config.spring.MuleHierarchicalBeanDefinitionParserDelegate;
import org.mule.config.spring.util.SpringXMLUtils;
import org.mule.module.getsatisfaction.config.CreateTopicMessageProcessor;
import org.mule.util.TemplateParser;
import org.springframework.beans.MutablePropertyValues;
import org.springframework.beans.PropertyValue;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.RuntimeBeanReference;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.ManagedList;
import org.springframework.beans.factory.xml.BeanDefinitionParser;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.util.xml.DomUtils;
import org.w3c.dom.Element;

public class CreateTopicDefinitionParser
    implements BeanDefinitionParser
{

    /**
     * Mule Pattern Info
     * 
     */
    private TemplateParser.PatternInfo patternInfo;

    public CreateTopicDefinitionParser() {
        patternInfo = TemplateParser.createMuleStyleParser().getStyle();
    }

    public BeanDefinition parse(Element element, ParserContext parserContent) {
        BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(CreateTopicMessageProcessor.class.getName());
        String configRef = element.getAttribute("config-ref");
        if ((configRef!= null)&&(!StringUtils.isBlank(configRef))) {
            builder.addPropertyValue("moduleObject", configRef);
        }
        if (element.hasAttribute("style")) {
            builder.addPropertyValue("style", element.getAttribute("style"));
        }
        if ((element.getAttribute("subject")!= null)&&(!StringUtils.isBlank(element.getAttribute("subject")))) {
            builder.addPropertyValue("subject", element.getAttribute("subject"));
        }
        if ((element.getAttribute("content")!= null)&&(!StringUtils.isBlank(element.getAttribute("content")))) {
            builder.addPropertyValue("content", element.getAttribute("content"));
        }
        Element productIdsListElement = null;
        productIdsListElement = DomUtils.getChildElementByTagName(element, "product-ids");
        List<Element> productIdsListChilds = null;
        if (productIdsListElement!= null) {
            String productIdsRef = productIdsListElement.getAttribute("ref");
            if ((productIdsRef!= null)&&(!StringUtils.isBlank(productIdsRef))) {
                if ((!productIdsRef.startsWith(patternInfo.getPrefix()))&&(!productIdsRef.endsWith(patternInfo.getSuffix()))) {
                    builder.addPropertyValue("productIds", new RuntimeBeanReference(productIdsRef));
                } else {
                    builder.addPropertyValue("productIds", productIdsRef);
                }
            } else {
                ManagedList productIds = new ManagedList();
                productIdsListChilds = DomUtils.getChildElementsByTagName(productIdsListElement, "product-id");
                if (productIdsListChilds!= null) {
                    for (Element productIdsChild: productIdsListChilds) {
                        String valueRef = productIdsChild.getAttribute("value-ref");
                        if ((valueRef!= null)&&(!StringUtils.isBlank(valueRef))) {
                            productIds.add(new RuntimeBeanReference(valueRef));
                        } else {
                            productIds.add(productIdsChild.getTextContent());
                        }
                    }
                }
                builder.addPropertyValue("productIds", productIds);
            }
        }
        Element keywordsListElement = null;
        keywordsListElement = DomUtils.getChildElementByTagName(element, "keywords");
        List<Element> keywordsListChilds = null;
        if (keywordsListElement!= null) {
            String keywordsRef = keywordsListElement.getAttribute("ref");
            if ((keywordsRef!= null)&&(!StringUtils.isBlank(keywordsRef))) {
                if ((!keywordsRef.startsWith(patternInfo.getPrefix()))&&(!keywordsRef.endsWith(patternInfo.getSuffix()))) {
                    builder.addPropertyValue("keywords", new RuntimeBeanReference(keywordsRef));
                } else {
                    builder.addPropertyValue("keywords", keywordsRef);
                }
            } else {
                ManagedList keywords = new ManagedList();
                keywordsListChilds = DomUtils.getChildElementsByTagName(keywordsListElement, "keyword");
                if (keywordsListChilds!= null) {
                    for (Element keywordsChild: keywordsListChilds) {
                        String valueRef = keywordsChild.getAttribute("value-ref");
                        if ((valueRef!= null)&&(!StringUtils.isBlank(valueRef))) {
                            keywords.add(new RuntimeBeanReference(valueRef));
                        } else {
                            keywords.add(keywordsChild.getTextContent());
                        }
                    }
                }
                builder.addPropertyValue("keywords", keywords);
            }
        }
        if ((element.getAttribute("retryMax")!= null)&&(!StringUtils.isBlank(element.getAttribute("retryMax")))) {
            builder.addPropertyValue("retryMax", element.getAttribute("retryMax"));
        }
        if ((element.getAttribute("email")!= null)&&(!StringUtils.isBlank(element.getAttribute("email")))) {
            builder.addPropertyValue("email", element.getAttribute("email"));
        }
        if ((element.getAttribute("uid")!= null)&&(!StringUtils.isBlank(element.getAttribute("uid")))) {
            builder.addPropertyValue("uid", element.getAttribute("uid"));
        }
        if ((element.getAttribute("fullName")!= null)&&(!StringUtils.isBlank(element.getAttribute("fullName")))) {
            builder.addPropertyValue("fullName", element.getAttribute("fullName"));
        }
        BeanDefinition definition = builder.getBeanDefinition();
        definition.setAttribute(MuleHierarchicalBeanDefinitionParserDelegate.MULE_NO_RECURSE, Boolean.TRUE);
        MutablePropertyValues propertyValues = parserContent.getContainingBeanDefinition().getPropertyValues();
        if (parserContent.getContainingBeanDefinition().getBeanClassName().equals("org.mule.config.spring.factories.PollingMessageSourceFactoryBean")) {
            propertyValues.addPropertyValue("messageProcessor", definition);
        } else {
            PropertyValue messageProcessors = propertyValues.getPropertyValue("messageProcessors");
            if ((messageProcessors == null)||(messageProcessors.getValue() == null)) {
                propertyValues.addPropertyValue("messageProcessors", new ManagedList());
            }
            List listMessageProcessors = ((List) propertyValues.getPropertyValue("messageProcessors").getValue());
            listMessageProcessors.add(definition);
        }
        return definition;
    }

    protected String getAttributeValue(Element element, String attributeName) {
        if (!StringUtils.isEmpty(element.getAttribute(attributeName))) {
            return element.getAttribute(attributeName);
        }
        return null;
    }

    private String generateChildBeanName(Element element) {
        String id = SpringXMLUtils.getNameOrId(element);
        if (StringUtils.isBlank(id)) {
            String parentId = SpringXMLUtils.getNameOrId(((Element) element.getParentNode()));
            return ((("."+ parentId)+":")+ element.getLocalName());
        } else {
            return id;
        }
    }

}
