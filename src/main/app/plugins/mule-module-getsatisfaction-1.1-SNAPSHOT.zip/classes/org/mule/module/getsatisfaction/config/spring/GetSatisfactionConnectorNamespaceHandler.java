
package org.mule.module.getsatisfaction.config.spring;

import org.springframework.beans.factory.xml.NamespaceHandlerSupport;


/**
 * Registers bean definitions parsers for handling elements in <code>http://www.mulesoft.org/schema/mule/getsatisfaction</code>.
 * 
 */
public class GetSatisfactionConnectorNamespaceHandler
    extends NamespaceHandlerSupport
{


    /**
     * Invoked by the {@link DefaultBeanDefinitionDocumentReader} after construction but before any custom elements are parsed. 
     * @see NamespaceHandlerSupport#registerBeanDefinitionParser(String, BeanDefinitionParser)
     * 
     */
    public void init() {
        registerBeanDefinitionParser("config", new GetSatisfactionConnectorConfigDefinitionParser());
        registerBeanDefinitionParser("create-topic", new CreateTopicDefinitionParser());
        registerBeanDefinitionParser("get-topic", new GetTopicDefinitionParser());
        registerBeanDefinitionParser("create-reply", new CreateReplyDefinitionParser());
        registerBeanDefinitionParser("get-topic-replies", new GetTopicRepliesDefinitionParser());
        registerBeanDefinitionParser("search-topics", new SearchTopicsDefinitionParser());
    }

}
